import json
import requests
import os

def lambda_handler(event, context):
    # Define payload
    payload = {
        "subnet_id": event['subnet_id'],
        "name": event['name'],
        "email": event['email']
    }
    
    # Define the API endpoint and headers
    url = os.environ['API_URL']  # Use an environment variable for the URL
    headers = {
        'X-Siemens-Auth': os.environ['AUTH_KEY']  # Use an environment variable for the auth key
    }
    
    try:
        # Make the POST request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()  # Raise an exception for bad HTTP responses
    except requests.exceptions.RequestException as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
    
    # Log the response
    return {
        'statusCode': 200,
        'body': json.dumps(response.json())
    }
